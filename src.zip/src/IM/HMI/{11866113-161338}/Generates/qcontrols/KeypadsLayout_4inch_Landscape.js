var row1Length = 10;
var row2Length = 9;
var row3Length = 7;
var rowLength = 5; // for portrait mode
var alphabet = new Array(26);
                //row1
alphabet[0]="Q";
alphabet[1]="W";
alphabet[2]="E";
alphabet[3]="R";
alphabet[4]="T";
alphabet[5]="Y";
alphabet[6]="U";
alphabet[7]="I";
alphabet[8]="O";
alphabet[9]="P";
                //row2
alphabet[10]="A";
alphabet[11]="S";
alphabet[12]="D";
alphabet[13]="F";
alphabet[14]="G";
alphabet[15]="H";
alphabet[16]="J";
alphabet[17]="K";
alphabet[18]="L";
                //row3
alphabet[19]="Z";
alphabet[20]="X";
alphabet[21]="C";
alphabet[22]="V";
alphabet[23]="B";
alphabet[24]="N";
alphabet[25]="M";

/**
 * Global object for keyboards number buttons. It's possible to change
 * Order of keyboards button from this file.
 */
var numbers = new Array(37);
                //row1
numbers[0]= "1";
numbers[1]= "2";
numbers[2]= "3";
numbers[3]= "4";
numbers[4]= "5";
numbers[5]= "6";
numbers[6]= "7";
numbers[7]= "8";
numbers[8]= "9";
numbers[9]= "0";
                //row2
numbers[10]= "(";
numbers[11]= ")";
numbers[12] = "\u20AC";
numbers[13]= "&";
numbers[14]= "@";
numbers[15]= "$";
numbers[16]= "%";
numbers[17]= "+";
numbers[18]= "#";
                //row3
numbers[19]= "!";
numbers[20]= ",";
numbers[21]= ".";
numbers[22]= ";";
numbers[23]= ":";
numbers[24]= "/";
numbers[25]= "_";
numbers[26]= "=";
              //more characters of row2
numbers[27]= "^";
numbers[28]= "[";
numbers[29]= "]";
numbers[30]= "|";
numbers[31]= "*";
numbers[32]= "-";
numbers[33]= "\"";
numbers[34]= "<";
numbers[35]= ">";
numbers[36]= "\\"

